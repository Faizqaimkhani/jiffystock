<?php

namespace App\Http\Controllers;

use App\Models\product_category;
use App\Models\product_images;
use App\Models\sub_category;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function index()
    {
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('cart.index', compact('nav', 'sub_nav'));
    }

    public function checkout(){
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('cart.checkout', compact('nav', 'sub_nav'));
    }
}
