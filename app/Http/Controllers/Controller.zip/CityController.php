<?php

namespace App\Http\Controllers;

use App\Models\city;
use App\Models\country;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\HelperController;
 
class CityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        // parent::__construct();
        //Do your magic here
        $this->middleware('auth');
        $this->middleware(function ($request, $next) {
            $this->user = Auth::user();

            if (Auth::user()->usertype != "admin") {
                return redirect('home');
            }
            return $next($request);
        });
    }

    public function index()
    {
        return view('admin.City.index')->with('cities', city::select('cities.*', 'countries.name as country_name')->leftjoin('countries', 'cities.country_id', '=', 'countries.id')->orderBy('countries.id', 'DESC')->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.City.add_city')->with('countries', country::get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'            => 'required',
            'country'            => 'required'
        ]);

        city::create([
            'name'         => $request->input('name'),
            'country_id'         => $request->input('country')
        ]);

        return redirect('/city')->with('message', 'City Inserted Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $city = city::select('cities.*', 'countries.id as country_id', 'countries.name as country_name')->leftjoin('countries', 'cities.country_id', '=', 'countries.id')->where('cities.id', $id)->first();
        $countries = country::get();

        return view('admin.City.edit_city', compact('city', 'countries'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'            => 'required',
            'country'            => 'required',
        ]);

        city::where('id', $id)->update([
            'name'         => $request->input('name'),
            'country_id'         => $request->input('country'),
        ]);

        return redirect('/city')->with('message', 'City Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $team = city::where('id', $id);
        $team->delete();

        return redirect('/city')->with('message', 'City Deleted Successfully');
    }

}
