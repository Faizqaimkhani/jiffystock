<?php

namespace App\Http\Controllers;

use App\Models\product_category;
use App\Models\product_images;
use App\Models\sub_category;
use App\Models\products;
use Illuminate\Http\Request;
use App\Models\city;
use App\Models\country;
use Illuminate\Support\Facades\Auth;

class HelperController extends Controller
{
    //
    public function all_products()
    {
        return view('admin.Products.all_products')->with('products', products::select('products.*', 'product_categories.name as category_name', 'sub_categories.name as sub_category_name', 'users.name as user_name')->leftjoin('sub_categories', 'products.sub_category_id', '=', 'sub_categories.id')->leftjoin('product_categories', 'sub_categories.category_id', '=', 'product_categories.id')->leftjoin('users', 'products.user_id', '=', 'users.id')->orderBy('id', 'DESC')->get());
    }

    public function cities($id)
    {

        $data['status'] = 400;

        $cities = city::where('country_id', $id)->get();

        if ($cities) {
            $data['status'] = 200;
            $data['data'] = $cities;
        }

        return json_encode($data);
    }

    public function sub_categories($id)
    {

        $data['status'] = 400;

        $sub_categories = sub_category::where('category_id', $id)->get();

        if ($sub_categories) {
            $data['status'] = 200;
            $data['data'] = $sub_categories;
        }

        return json_encode($data);
    }
}
