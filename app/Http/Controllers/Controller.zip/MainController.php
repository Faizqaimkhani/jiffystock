<?php

namespace App\Http\Controllers;

use App\Models\product_category;
use App\Models\product_images;
use App\Models\sub_category;
use Illuminate\Http\Request;

class MainController extends Controller
{

    
    public function __construct()
    {
        //Do your magic here
    }
    

    public function index()
    {
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('index', compact('nav', 'sub_nav'));
    }

    public function contactUs()
    {
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('contactUs', compact('nav', 'sub_nav'));
    }

    public function aboutUs()
    {
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('aboutUs', compact('nav', 'sub_nav'));
    }

    public function productDetails()
    {
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('products.productDetails', compact('nav', 'sub_nav'));
    }

    public function blogs()
    {
        $nav = product_category::get();
        $sub_nav = sub_category::get();
        return view('Blogs.index', compact('nav', 'sub_nav'));
    }
}
