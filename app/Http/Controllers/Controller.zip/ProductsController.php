<?php

namespace App\Http\Controllers;

use App\Models\product_category;
use App\Models\product_images;
use App\Models\sub_category;
use App\Models\products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


    public function __construct()
    {
        // parent::__construct();
        //Do your magic here
        $this->middleware('auth');
        $this->middleware(function ($request, $next) {
            $this->user = Auth::user();

            if (Auth::user()->usertype != "user") {
                return redirect('home');
            }
            return $next($request);
        });
    }


    public function index()
    {
        return view('admin.Products.index')->with('products', products::select('products.*', 'product_categories.name as category_name', 'sub_categories.name as sub_category_name')->leftjoin('sub_categories', 'products.sub_category_id', '=', 'sub_categories.id')->leftjoin('product_categories', 'sub_categories.category_id', '=', 'product_categories.id')->orderBy('product_categories.id', 'DESC')->where('user_id', Auth::id())->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.Products.add_product')->with('categories', product_category::get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'            => 'required',
            'category'            => 'required',
            'sub_category'            => 'required',
            'price'            => 'required',
            'stock_quantity'            => 'required',
            'video'        => 'mimes:mp4,flv,avi,wmv',
            'image1'        => 'mimes:jpg,png,jpeg|max:5048',
            'image2'        => 'mimes:jpg,png,jpeg|max:5048',
            'image3'        => 'mimes:jpg,png,jpeg|max:5048',
            'image4'        => 'mimes:jpg,png,jpeg|max:5048',
            'image5'        => 'mimes:jpg,png,jpeg|max:5048',
        ]);







        if ($request->video) {
            $video = uniqid() . '-' . $request->name . '.' . $request->video->extension();
            $request->video->move(public_path('uploads/Products-Videos'), $video);
        } else {
            $video = "";
        }

        if ($request->image1) {
            $image1 = uniqid() . '-' . $request->name . '.' . $request->image1->extension();
            $request->image1->move(public_path('uploads/Products-Images'), $image1);
        } else {
            $image1 = "";
        }

        if ($request->image2) {
            $image2 = uniqid() . '-' . $request->name . '.' . $request->image2->extension();
            $request->image2->move(public_path('uploads/Products-Images'), $image2);
        } else {
            $image2 = "";
        }

        if ($request->image3) {
            $image3 = uniqid() . '-' . $request->name . '.' . $request->image3->extension();
            $request->image3->move(public_path('uploads/Products-Images'), $image3);
        } else {
            $image3 = "";
        }

        if ($request->image4) {
            $image4 = uniqid() . '-' . $request->name . '.' . $request->image4->extension();
            $request->image4->move(public_path('uploads/Products-Images'), $image4);
        } else {
            $image4 = "";
        }

        if ($request->image5) {
            $image5 = uniqid() . '-' . $request->name . '.' . $request->image5->extension();
            $request->image5->move(public_path('uploads/Products-Images'), $image5);
        } else {
            $image5 = "";
        }

        // dd($image1, $image2);


        products::create([
            'name' => $request->input('name'),
            'sub_category_id' => $request->input('sub_category'),
            'price' => $request->input('price'),
            'stock_quantity' => $request->input('stock_quantity'),
            'user_id' => Auth::id(),
            'video' => $video,
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5
        ]);

        return redirect('/products')->with('message', 'Product Inserted Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = products::select('products.*', 'sub_categories.id as sub_category_id', 'sub_categories.name as sub_category_name', 'product_categories.id as category_id', 'product_categories.name as category_name')->leftjoin('sub_categories', 'products.sub_category_id', '=', 'sub_categories.id')->leftjoin('product_categories', 'sub_categories.category_id', '=', 'product_categories.id')->where('products.id', $id)->first();
        $user_all_products = products::select('*')->where('user_id', Auth::id())->get();
        // dd($user_all_products);
        foreach ($user_all_products as $key => $value) {
            $check = "";
            if($value->id == $product->id){
                $check = 1;
            }
        }
        if($check == ""){
            return redirect('/products');
        }
        $categories = product_category::get();
        return view('admin.Products.edit_product', compact('product', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'            => 'required',
            'category'            => 'required',
            'sub_category'            => 'required',
            'price'            => 'required',
            'stock_quantity'            => 'required',
            'video'        => 'mimes:mp4,flv,avi,wmv',
            'image1'        => 'mimes:jpg,png,jpeg|max:5048',
            'image2'        => 'mimes:jpg,png,jpeg|max:5048',
            'image3'        => 'mimes:jpg,png,jpeg|max:5048',
            'image4'        => 'mimes:jpg,png,jpeg|max:5048',
            'image5'        => 'mimes:jpg,png,jpeg|max:5048',
        ]);

        if (!$request->video) {
            $video = $request->old_video;
        } else {
            $video = uniqid() . '-' . $request->name . '.' . $request->video->extension();
            $request->video->move(public_path('uploads/Products-Videos'), $video);
        }

        if (!$request->image1) {
            $image1 = $request->old_image1;
        } else {
            $image1 = uniqid() . '-' . $request->name . '.' . $request->image1->extension();
            $request->image1->move(public_path('uploads/Products-Images'), $image1);
        }

        if (!$request->image2) {
            $image2 = $request->old_image2;
        } else {
            $image2 = uniqid() . '-' . $request->name . '.' . $request->image2->extension();
            $request->image2->move(public_path('uploads/Products-Images'), $image2);
        }

        if (!$request->image3) {
            $image3 = $request->old_image3;
        } else {
            $image3 = uniqid() . '-' . $request->name . '.' . $request->image3->extension();
            $request->image3->move(public_path('uploads/Products-Images'), $image3);
        }

        if (!$request->image4) {
            $image4 = $request->old_image4;
        } else {
            $image4 = uniqid() . '-' . $request->name . '.' . $request->image4->extension();
            $request->image4->move(public_path('uploads/Products-Images'), $image4);
        }

        if (!$request->image5) {
            $image5 = $request->old_image5;
        } else {
            $image5 = uniqid() . '-' . $request->name . '.' . $request->image5->extension();
            $request->image5->move(public_path('uploads/Products-Images'), $image5);
        }

        products::where('id', $id)->update([
            'name' => $request->input('name'),
            'sub_category_id' => $request->input('sub_category'),
            'price' => $request->input('price'),
            'stock_quantity' => $request->input('stock_quantity'),
            'video' => $video,
            'image1' => $image1,
            'image2' => $image2,
            'image3' => $image3,
            'image4' => $image4,
            'image5' => $image5
        ]);
        // dd('check');
        return redirect('/products')->with('message', 'Product Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $product = products::where('id', $id);
        $product->delete();

        return redirect('/products')->with('message', 'Product Deleted Successfully');
    }

}
