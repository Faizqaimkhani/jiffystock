<?php

namespace App\Http\Controllers;

use App\Models\user;

use App\Models\product_category;
use App\Models\sub_category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductsSubCategoryController extends Controller
{
    /**
     * Display a listing of the resource. 
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        // parent::__construct();
        //Do your magic here
        $this->middleware('auth');
        $this->middleware(function ($request, $next) {
            $this->user = Auth::user();

            if (Auth::user()->usertype != "admin") {
                return redirect('home');
            }
            return $next($request);
        });
    }

    public function index()
    {
        return view('admin.Product Categories.Sub Categories.index')->with('sub_categories', sub_category::select('sub_categories.*', 'product_categories.name as category_name')->leftjoin('product_categories', 'sub_categories.category_id', '=', 'product_categories.id')->orderBy('product_categories.id', 'DESC')->get());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    { 
        return view('admin.Product Categories.Sub Categories.add_sub_category')->with('categories', product_category::get());
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'name'            => 'required',
            'category'            => 'required'
        ]);

        $sub_cat = sub_category::create([
            'name'         => $request->input('name'),
            'category_id'         => $request->input('category')
        ]);

        // dd($sub_cat->id);
        return redirect('/products-sub-category')->with('message', 'Product Sub Category Inserted Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $sub_category = sub_category::select('sub_categories.*', 'product_categories.id as category_id', 'product_categories.name as category_name')->leftjoin('product_categories', 'sub_categories.category_id', '=', 'product_categories.id')->where('sub_categories.id', $id)->first();
        $categories = product_category::get();

        return view('admin.Product Categories.Sub Categories.edit_sub_category', compact('sub_category', 'categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name'            => 'required',
            'category'            => 'required',
        ]);

        sub_category::where('id', $id)->update([
            'name'         => $request->input('name'),
            'category_id'         => $request->input('category'),
        ]);

        return redirect('/products-sub-category')->with('message', 'Product Sub Category Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $sub_category = sub_category::where('id', $id);
        $sub_category->delete();

        return redirect('/products-sub-category')->with('message', 'Products Sub Category Deleted Successfully');
    }

    public function sub_categories($id)
    {

        $data['status'] = 400;

        $sub_categories = sub_category::where('category_id', $id)->get();

        if ($sub_categories) {
            $data['status'] = 200;
            $data['data'] = $sub_categories;
        }

        return json_encode($data);
    }

}
