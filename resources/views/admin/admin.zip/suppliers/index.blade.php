@extends('layouts.dashboard')

@section('content')
                    <!-- begin container-fluid -->
                    <div class="container-fluid">
                        <!-- begin row -->
                        <div class="row">
                            <div class="col-md-12 m-b-30">
                                <!-- begin page title -->
                                <div class="d-block d-sm-flex flex-nowrap align-items-center">
                                    <div class="page-title mb-2 mb-sm-0">
                                        <h1>Suppliers</h1>
                                    </div>
                                    <div class="ml-auto d-flex align-items-center">
                                        <nav>
                                            <ol class="breadcrumb p-0 m-b-0">
                                                <li class="breadcrumb-item">
                                                    <a href="/home"><i class="ti ti-home"></i></a>
                                                </li>
                                                <li class="breadcrumb-item">
                                                    Suppliers
                                                </li>
                                                <li class="breadcrumb-item active text-primary" aria-current="page"></li>
                                            </ol>
                                        </nav>
                                    </div>
                                </div>
                                <!-- end page title -->
                            </div>
                        </div>
                        <!-- end row -->
                        <!-- begin row -->
                        @if (session()->has('message'))
                            <div class="alert alert-primary alert-dismissible fade show" role="alert">
                                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    <span class="sr-only">Close</span>
                                </button>
                                <span>{{ session()->get('message') }}</span>
                            </div>
                            <br>
                            @endif
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="row">
                                    <div class="col text-right">
                                
                                </div>
                            </div>
                                <div class="card card-statistics">
                                    <div class="card-body">
                                        <div class="datatable-wrapper table-responsive">
                                            <table id="datatable" class="display compact table table-striped table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th style="width: 30%">Name</th>
                                                        <th style="width: 20%">Email</th>
                                                        <th style="width: 20%">Company</th>
                                                        <th style="width: 10%">Compant License</th>
                                                        <th style="width: 10%">Country</th>
                                                        <th style="width: 10%">City</th>
                                                        <th style="width: 10%">Time</th>
                                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    @foreach ($users as $item)
                                                        <tr>
                                                            <td>{{ $item->name }}</td>
                                                            <td>{{ $item->email }}</td>
                                                            <td>{{ $item->company }}</td>
                                                            <td>{{ $item->contact_number }}</td>
                                                            <td>
                                                         
                                                              
                                                                @if($item->country > 0)
                                                                {{ $item->countries->name }}
                                                                @endif
                                                            </td>
                                                            <td>
                                                            @if($item->city > 0)
                                                                {{ $item->cities->name }}
                                                                @endif
                                                            </td>
                                                            <td>{{ $item->created_at->diffForHumans() }}</td>
                                                            
                                                        </tr>
                                                    @endforeach
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>Name</th>
                                                    </tr>
                                                </tfoot>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div>
                    <!-- end container-fluid -->
@endsection
